let snake;
let food = [];
let score = 0;
let win = false;

function setup() {
  createCanvas(600, 600);
  snake = new Snake();
  for (let i = 0; i < 15; i++) {
    food.push(new Food());
  }
}

function draw() {
  background(20);

  if (score >= 500) {
    win = true;
    fill(0, 255, 0);
    textSize(50);
    textAlign(CENTER, CENTER);
    text("Você Venceu!", width / 2, height / 2);
    noLoop();
    return;
  }

  snake.update();
  snake.show();

  for (let i = food.length - 1; i >= 0; i--) {
    food[i].show();
    if (snake.eats(food[i])) {
      score += 10;
      food.splice(i, 1);
      food.push(new Food());
    }
  }

  fill(255);
  textSize(20);
  text("Pontos: " + score, 10, 20);
}

function keyPressed() {
  if (keyCode === UP_ARROW) snake.setDir(0, -1);
  else if (keyCode === DOWN_ARROW) snake.setDir(0, 1);
  else if (keyCode === LEFT_ARROW) snake.setDir(-1, 0);
  else if (keyCode === RIGHT_ARROW) snake.setDir(1, 0);
}

class Snake {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 20;
    this.xdir = 0;
    this.ydir = 0;
  }

  setDir(x, y) {
    this.xdir = x;
    this.ydir = y;
  }

  update() {
    this.x += this.xdir * this.size;
    this.y += this.ydir * this.size;
    this.x = constrain(this.x, 0, width - this.size);
    this.y = constrain(this.y, 0, height - this.size);
  }

  show() {
    fill(50, 200, 255);
    rect(this.x, this.y, this.size, this.size, 5);
  }

  eats(f) {
    return dist(this.x, this.y, f.x, f.y) < this.size;
  }
}

class Food {
  constructor() {
    this.x = floor(random(width / 20)) * 20;
    this.y = floor(random(height / 20)) * 20;
    this.color = color(random(255), random(255), random(255));
  }

  show() {
    fill(this.color);
    ellipse(this.x + 10, this.y + 10, 15 + 5 * sin(frameCount * 0.1), 15 + 5 * cos(frameCount * 0.1));
  }
}